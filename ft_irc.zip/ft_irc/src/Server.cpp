/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Server.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alirola- <alirola-@student.42malaga.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 17:01:49 by alirola-          #+#    #+#             */
/*   Updated: 2024/12/10 17:01:53 by alirola-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Server.hpp"
#include <unistd.h> // close
#include <cstring>  // memset
#include <arpa/inet.h> // htons, inet_ntoa
#include <stdexcept> // std::runtime_error

Server::Server(int port, const std::string& password)
    : server_fd(-1), password(password) {
    // Crear el socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == -1) {
        throw std::runtime_error("Error al crear el socket");
    }

    // Configurar el socket
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Vincular el socket
    if (bind(server_fd, (sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        close(server_fd);
        throw std::runtime_error("Error al vincular el socket");
    }

    // Escuchar conexiones entrantes
    if (listen(server_fd, SOMAXCONN) == -1) {
        close(server_fd);
        throw std::runtime_error("Error al escuchar en el socket");
    }

    // Inicializar el vector de pollfd con el descriptor del servidor
    pollfd server_pollfd;
    server_pollfd.fd = server_fd;
    server_pollfd.events = POLLIN;
    fds.push_back(server_pollfd);

    std::cout << "Servidor iniciado en el puerto " << port << std::endl;
}

Server::~Server() {
    close(server_fd);
    for (const auto& fd : fds) {
        close(fd.fd);
    }
    std::cout << "Servidor cerrado." << std::endl;
}

void Server::run() {
    while (true) {
        int poll_count = poll(fds.data(), fds.size(), -1);
        if (poll_count == -1) {
            perror("Poll falló");
            break;
        }

        for (size_t i = 0; i < fds.size(); ++i) {
            if (fds[i].revents & POLLIN) {
                if (fds[i].fd == server_fd) {
                    acceptNewClient();
                } else {
                    handleClientMessage(fds[i].fd);
                }
            }
        }
    }
}

void Server::acceptNewClient() {
    sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);
    int client_fd = accept(server_fd, (sockaddr*)&client_addr, &client_len);
    if (client_fd == -1) {
        perror("Error al aceptar cliente");
        return;
    }

    pollfd client_pollfd;
    client_pollfd.fd = client_fd;
    client_pollfd.events = POLLIN;
    fds.push_back(client_pollfd);

    clients[client_fd] = ""; // Inicializar cliente sin apodo

    std::cout << "Cliente conectado desde " << inet_ntoa(client_addr.sin_addr) << std::endl;
}

void Server::handleClientMessage(int client_fd) {
    char buffer[512];
    memset(buffer, 0, sizeof(buffer));
    int bytes_received = recv(client_fd, buffer, sizeof(buffer) - 1, 0);

    if (bytes_received <= 0) {
        std::cout << "Cliente desconectado: " << client_fd << std::endl;
        removeClient(client_fd);
        return;
    }

    std::cout << "Mensaje recibido de " << client_fd << ": " << buffer;

    // Aquí puedes procesar comandos del cliente
    // Por ahora, simplemente responderemos con un mensaje de eco
    std::string response = "ECO: " + std::string(buffer);
    send(client_fd, response.c_str(), response.size(), 0);
}

void Server::removeClient(int client_fd) {
    close(client_fd);
    fds.erase(std::remove_if(fds.begin(), fds.end(), [client_fd](const pollfd& pfd) {
        return pfd.fd == client_fd;
    }), fds.end());
    clients.erase(client_fd);
}
