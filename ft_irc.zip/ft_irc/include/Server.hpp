/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Server.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alirola- <alirola-@student.42malaga.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 16:35:55 by alirola-          #+#    #+#             */
/*   Updated: 2024/12/10 16:57:54 by alirola-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <poll.h>
#include <netinet/in.h>

class Server {
private:
    int                 server_fd;           // Socket del servidor
    std::string         password;            // Contraseña para autenticación
    sockaddr_in         server_addr;         // Dirección del servidor
    std::vector<pollfd> fds;                 // Vector de pollfd para manejar clientes
    std::map<int, std::string> clients;      // Mapeo de socket a nombres de cliente

    void acceptNewClient();                  // Manejar nuevas conexiones
    void handleClientMessage(int client_fd); // Manejar mensajes de un cliente
    void removeClient(int client_fd);        // Eliminar un cliente desconectado

public:
    Server(int port, const std::string& password);
    ~Server();

    void run(); // Ejecutar el servidor
};
